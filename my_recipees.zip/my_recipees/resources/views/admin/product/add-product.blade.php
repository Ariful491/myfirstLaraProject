@extends('admin.master')
@section('body')


    <!-- Begin Page Content -->
    <div class="container-fluid">
        @if(Session::get('text'))
            <div class="col-md-4 ml-auto">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <h1>{{Session::get('text')}}</h1>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>
            </div>

        @endif


        <h1>Add Product</h1>

        <form action="{{route('new-product')}}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="categoryname">Product Name</label>
                <input type="text" name="product_name" class="form-control" id="categoryname">
            </div>
            <div class="form-group">
                <label for="product-details">Product Details</label>
                <textarea rows="5"class="form-control" name="product_details" id="editor"></textarea>
            </div>
            <div class="form-group">
                <label for="categoryname">Product Price</label>
                <input type="text" class="form-control" name="product_price" id="categoryname">
            </div>
            <div class="form-group">
                <label for="categoryname">Product Cupon Price</label>
                <input type="text" class="form-control" name="cupon_price" id="categoryname">
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect1">select category </label>
                <select class="form-control" id="exampleFormControlSelect1" name="category_id">
                    <option>---Select Category---</option>
                    @foreach($categories as $category)
                    <option value="{{$category->id}}">{{$category->cat_nam}}</option>
                        @endforeach

                </select>
            </div>

            <div class="form-group">
                <label for="exampleFormControlSelect1">select Food Type </label>
                <select class="form-control" id="exampleFormControlSelect1" name="food_id">
                    <option>---Select Food Type---</option>
                    @foreach($foodtypes as $foodtype)
                    <option value="{{$foodtype->id}}">{{$foodtype->food_name}}</option>
                        @endforeach
                </select>
            </div>
{{--            <div class="form-group">--}}
{{--                <label for="exampleFormControlSelect1">select Color</label>--}}
{{--                <select class="form-control" id="exampleFormControlSelect1" name="product_color">--}}
{{--                    <option>---Select Food color---</option>--}}
{{--                    <option value="yellow">Yellow</option>--}}
{{--                    <option value="green">Green</option>--}}
{{--                    <option value="white">White</option>--}}

{{--                </select>--}}
{{--            </div>--}}
            <div class="form-group">
                <label for="exampleFormControlSelect1">select Quantity</label>
                <select class="form-control" id="exampleFormControlSelect1" name="product_size">
                    <option >--Select Food Quantity </option>
                    <option value="m" >m</option>
                    <option value="l">l</option>
                    <option value="x">x</option>
                    <option value="xl">xl</option>
                    <option value="xxl">xxl</option>
                </select>
            </div>
            <div class="form-group">
                <label for="exampleFormControlFile1">Image</label>

                <input type="file" class="form-control-file" id="exampleFormControlFile1" name="main_image">
            </div>
            <div class="form-group">
                <label for="exampleFormControlFile1">Image Gallery</label>

                <input type="file" class="form-control-file" id="exampleFormControlFile1" multiple name="filename[]">
            </div>
            <input type="submit" class="btn btn-primary">
        </form>

    </div>
    <!-- /.container-fluid -->
    @endsection
