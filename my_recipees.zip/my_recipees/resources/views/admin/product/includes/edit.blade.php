

                <!-- Modal -->
                <div class="modal fade" id="edit{{$product->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">View Product Info</h5>
                                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="{{route('edit-product')}}" method="post" enctype="multipart/form-data">
                                    @csrf
                                    <div class="form-group">
                                        <label >Product Name:</label>
                                        <input type="text"  name="product_name" class="form-control" value="{{$product->product_name}}">
                                        <input type="hidden"  name="id" class="form-control" value="{{$product->id}}">
                                    </div>
                                    <div class="form-group">
                                        <label >Product Details:</label>
                                        <input type="text"  name="product_details" class="form-control" value="{!!$product->product_details!!}">

                                    </div>
                                    <div class="form-group">
                                        <label >Product Price:</label>
                                        <input type="text"  name="product_price" class="form-control" value="{{$product->product_price}}">
                                    </div>
                                    <div class="form-group">
                                        <label >Cupon Price:</label>
                                        <input type="text"  name="cupon_price" class="form-control" value="{{$product->cupon_price}}">
                                    </div>



                                    <div class="form-group">
                                        <label for="exampleFormControlFile1">Image</label>
                                        <h5>Product Image:</h5>
                                        <img src="{{asset($product->main_image)}}" alt="" width="200px" height="200px" >
                                        <br>
                                        <input type="file" class="form-control-file"  name="main_image" id="exampleFormControlFile1">
                                    </div>
                                     <div class="form-group">
                                        <label for="exampleFormControlFile1">Image</label>
                                        <h5>Product Gallery:</h5>

                                         @foreach(json_decode($product->filename) as $img)
                                             <img  src="{{asset($img)}}" width="300px" height="200">
                                         @endforeach

                                        <br> <br>
                                        <input type="file" class="form-control-file"  name="filename[]" id="exampleFormControlFile1" multiple>
                                    </div>


                                    <input type="submit" class="btn btn-success" name="btn" value="Update Products">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
