<!-- Modal -->
<div class="modal fade" id="view{{$product->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-danger" id="exampleModalLabel">View Product Info</h5>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <h3 class="text-danger">Product Name:</h3>
                            <p>{{$product->product_name}}</p>
                        </div>
                    </div>
                    <hr>
                    <div class="row">

                        <div class="col-md-4">
                        <h3 class="text-danger">Product Details:</h3>
                            <p>{!!$product->product_details!!}</p></div>

                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-4">
                        <h3 class="text-danger">Product Price:</h3>
                            <p>{{$product->product_price}}</p></div>

                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-8">
                        <h3 class="text-danger">Product Price And Cupon Price:</h3>
                        <p>{{$product->cupon_price  }}TK -{{$product->cupon_price}}TK</p>
                        </div>
                    </div>   <hr>

                    <div class="row">
                        <div class="col-md-12">
                        <h2 class="text-danger">Product Image:</h2>
                        <img  src="{{asset($product->main_image)}}" width="300px"  height="200">
                        </div></div>   <hr>

                    <div class="row">
                        <div class="col-">
                        <h3 class="text-danger"> Image Gallery:</h3>

                        @foreach(json_decode($product->filename) as $img)
                            <img  src="{{asset($img)}}" width="300px" height="200">
                        @endforeach

                        </div></div>

                    </div>






                </div>



            </div>
        </div>
    </div>

