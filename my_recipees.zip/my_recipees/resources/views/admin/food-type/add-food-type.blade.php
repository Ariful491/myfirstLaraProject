@extends('admin.master')
@section('body')

    <div class="container-fluid">

        @if(Session::get('text'))
            <div class="col-md-4 ml-auto">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <h1>{{Session::get('text')}}</h1>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>
            </div>

        @endif


        <h1>Food Types</h1>
            {{ Form::open(['route'=>'add-food','enctype'=>'multipart/form-data'])}}

            <div class="form-group">
            {{Form::label('Food Name')}}<sup class="text-danger">*</sup>:
            {{Form::text('food_name','',['class'=>'form-control bg-white text-dark',])}}
                <span style="color: red">{{$errors->has('food_name') ? $errors->first('food_name'):''}}</span>
            </div>

            <div class="form-group">
            {{Form::label('Food Description')}}<sup class="text-danger">*</sup>:
            {{Form::textarea('food_description','',['class'=>'form-control bg-white text-dark ','rows'=>'5'])}}
                <span cstyle="color: red">{{$errors->has('food_description') ? $errors->first('food_description'):''}}</span>

            </div>

          <div class="form-group">
            {{Form::label('Food image')}}<sup class="text-danger">*</sup>:
            {{Form::file('food_image',['class'=>'form-control-file'])}}
              <span style="color: red">{{$errors->has('food_image') ? $errors->first('food_image'):''}}</span>

          </div>

            <div class="form-group">
            {{Form::label('Publication Status')}}<sup class="text-danger">*</sup>:
                <div class="radio">
                    {{Form::radio('status','1')}}Published
                    {{Form::radio('status','0')}}Unpublished
                </div>
                <span style="color: red">{{$errors->has('status') ? $errors->first('status'):''}}</span>

            </div>
             <hr>

            <div class="form-group">
                {{Form::submit('Add Food Type',['class'=>'btn btn-danger'])}}
            </div>
             {{ Form::close() }}

    </div>
    <!-- /.container-fluid -->

    @endsection
