@extends('admin.master')

@section('body')
    <div class="container-fluid">
        @if(Session::get('text'))
            <div class="col-md-4 ml-auto ">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <h1>{{Session::get('text')}}</h1>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>
            </div>

        @endif
        <h1>View Food Types</h1>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">Serial</th>
                <th scope="col">Food Name</th>
                <th scope="col">Food Description</th>
                <th scope="col">Food Image</th>
                <th scope="col">Publication Status</th>
                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            @php($i=1)
            @foreach($foodtypes as $foodtype)
                <tr>


                    <td scope="row">{{$i++}} </td>
                    <td>{{$foodtype->food_name}}</td>
                    <td>{{$foodtype->food_description}}</td>
                    <td><img  src="{{asset($foodtype->food_image)}}" width="100"  > </td>
                    <td>{{$foodtype->status==1?'publish':'unpublished'}}</td>

                    <td><!-- Button trigger modal -->
                        @if($foodtype->status==1)
                            <a href="{{route('published-foodtype',['id'=>$foodtype->id])}}" type="button" class="btn btn-info" >
                                <i class=" fas fa-arrow-up"></i>
                            </a>
                        @else

                            <a href="{{route('unpublished-foodtype',['id'=>$foodtype->id])}}" type="button" class="btn btn-warning" >
                                <i class="fas fa-arrow-down"></i>
                            </a>
                        @endif

                        <button  type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal{{$foodtype->id}}">
                            <i class="fas fa-edit"></i>
                        </button>

                        <a href="{{route('delete-food',['id'=>$foodtype->id])}}" type="button" class="btn btn-danger" >
                            <i class="fas fa-trash"></i>
                        </a>



                    </td>
                </tr>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal{{$foodtype->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Update Food Types</h5>
                                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="{{route('update-food')}}" method="post" enctype="multipart/form-data">
                                    @csrf
                                    <div class="form-group">
                                        <label >Food Name</label>
                                        <input type="text"  name="food_name" class="form-control" value="{{$foodtype->food_name}}">
                                        <input type="hidden"  name="id" class="form-control" value="{{$foodtype->id}}">
                                    </div>
                                    <div class="form-group">
                                        <label >Food Description</label>
                                        <textarea rows="4" name="food_description" class="form-control" >{{$foodtype->food_description}}</textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleFormControlFile1">Image</label>
                                        <h5>Previus Image</h5>
                                        <img src="{{asset($foodtype->food_image)}}" alt="" width="200px" height="200px" >
                                        <br><br>
                                        <input type="file" class="form-control-file"  name="food_image" id="exampleFormControlFile1">
                                    </div>
                                    <input type="submit" class="btn btn-success" name="btn" value="Update Food">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
            </tbody>
        </table>
    </div>
    <!-- /.contai

    @endsection



