@extends('admin.master')

@section('body')
    <div class="container-fluid  ">
        <h1>Dashboard</h1>
        <p>Welcome to my admin panel</p>




    </div>
    @endsection
