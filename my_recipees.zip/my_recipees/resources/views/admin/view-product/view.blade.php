@extends('admin.master')
@section('body')


    <!-- Begin Page Content -->
    <div class="container-fluid">
        @if(Session::get('text'))
            <div class="col-md-4 ml-auto ">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <h1>{{Session::get('text')}}</h1>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>
            </div>

        @endif
        <h1>View Product</h1>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">Serial</th>
                <th scope="col">Product Name</th>
                <th scope="col">Price</th>
                <th scope="col"> Image</th>
                <th scope="col"> Category</th>
                <th scope="col"> Food Type</th>

                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            @php($i=1)
            @foreach($products as $product)
                <tr>


                    <td scope="row">{{$i++}} </td>
                    <td>{{$product->product_name}}</td>
                    <td>{{$product->product_price}}</td>
                    <td><img  src="{{asset($product->main_image)}}" width="100"  > </td>
                    <td>{{$product->cat_nam}}</td>
                    <td>{{$product->food_name}}</td>


                    <td><!-- Button trigger modal -->


                        <button  type="button" class="btn btn-info" data-toggle="modal" data-target="#view{{$product->id}}">
                            <i class="fas fa-search-plus"></i>
                        </button>

                        <button  type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit{{$product->id}}">
                            <i class="fas fa-edit"></i>
                        </button>

                        <a href="{{route('delete-category',['id'=>$product->id])}}" type="button" class="btn btn-danger" >
                            <i class="fas fa-trash"></i>
                        </a>



                    </td>
                </tr>



                @include('admin.product.includes.view')


                @include('admin.product.includes.edit')





{{--                <!-- Modal -->--}}
{{--                <div class="modal fade" id="view{{$product->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">--}}
{{--                    <div class="modal-dialog modal-lg" role="document">--}}
{{--                        <div class="modal-content">--}}
{{--                            <div class="modal-header">--}}
{{--                                <h5 class="modal-title" id="exampleModalLabel">View Product Info</h5>--}}
{{--                                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">--}}
{{--                                    <span aria-hidden="true">&times;</span>--}}
{{--                                </button>--}}
{{--                            </div>--}}
{{--                            <div class="modal-body">--}}
{{--                                <form action="{{route('update-category')}}" method="post" enctype="multipart/form-data">--}}
{{--                                    @csrf--}}
{{--                                    <div class="form-group">--}}
{{--                                        <label >Category Name</label>--}}
{{--                                        <input type="text"  name="cat_nam" class="form-control" value="{{$product->cat_nam}}">--}}
{{--                                        <input type="hidden"  name="id" class="form-control" value="{{$product->id}}">--}}
{{--                                    </div>--}}
{{--                                    <div class="form-group">--}}
{{--                                        <label >Category Description</label>--}}
{{--                                        <textarea rows="4" name="cat_desc" class="form-control" >{{$product->cat_desc}}</textarea>--}}
{{--                                    </div>--}}
{{--                                    <div class="form-group">--}}
{{--                                        <label for="exampleFormControlFile1">Image</label>--}}
{{--                                        <h5>Previus Image</h5>--}}
{{--                                        <img src="{{asset($product->main_image)}}" alt="" width="200px" height="200px" >--}}
{{--                                        <br><br>--}}
{{--                                        <input type="file" class="form-control-file"  name="cat_image" id="exampleFormControlFile1">--}}
{{--                                    </div>--}}
{{--                                    <input type="submit" class="btn btn-success" name="btn" value="Update Category">--}}
{{--                                </form>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
            @endforeach
            </tbody>
        </table>
    </div>
    <!-- /.container-fluid -->


    @endsection
