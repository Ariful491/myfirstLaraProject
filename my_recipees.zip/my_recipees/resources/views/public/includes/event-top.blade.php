<div class="events-info wow fadeInUpBig animated" data-wow-delay="0.4s">
    <h3>Events</h3>
    <div class="border"></div>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed
        do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat deserunt
        mollit anim id est laborum.</p>
</div>
