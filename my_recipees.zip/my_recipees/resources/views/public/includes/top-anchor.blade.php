<div class="header">
    <div class="container">
        <div class="logo  wow bounceInDown animated" data-wow-delay="0.4s">
            <a href="index.html"><img src="{{asset('/public/public')}}/images/logo.png" alt="" /></a>
        </div>
        <div class="header-right wow fadeInLeft animated" data-wow-delay="0.5s">
            <div class="social-icons">
                <li><a href="#"><i class="twitter"></i></a></li>
                <li><a href="#"><i class="facebook"></i></a></li>
                <li><a href="#"><i class="rss"></i></a></li>
                <li><div class="facebook"><div id="fb-root"></div>
                        <div id="fb-root"></div>
                    </div></li>
                <script>(function(d, s, id) {
                        var js, fjs = d.getElementsByTagName(s)[0];
                        if (d.getElementById(id)) return;
                        js = d.createElement(s); js.id = id;
                        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
                        fjs.parentNode.insertBefore(js, fjs);
                    }(document, 'script', 'facebook-jssdk'));</script>
                <div class="fb-like" data-href="https://www.facebook.com/w3layouts" data-layout="button_count" data-action="like" data-show-faces="true" data-share="false"></div>
            </div>
            <div class="search">
                <form>
                    <input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}"/>
                    <input type="submit" value="">
                </form>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
