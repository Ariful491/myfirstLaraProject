@extends('public.master')

@section('title')

My Recipes a Food Category Flat Bootstrap Responsive WebSite Template | Home :: w3layouts
    @endsection
@section("body")
    <div class="service text-center">
        <h4 class="wow fadeInLeft animated" data-wow-delay="0.4s">Receive great food</h4>
        <h3 class="wow fadeInLeft animated" data-wow-delay="0.4s">AND HIGH <span>QUALITY</span> SERVICE</h3>
        <p class="wow fadeInUpBig animated animated" data-wow-delay="0.4s">Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit an</p>
    </div>
    <!---->
    <div id="about" class="about">
        <div class="about-top">@foreach($testOfAsian as $test)
            <div class="col-md-6 about-device wow bounceInLeft animated">


                <img src="{{asset($test->food_image)}}" alt=""/>

            </div>
            <div class="col-md-6 about-device-info wow bounceInRight animated">
                <div class="device-text">
                    <h2>Experience The Taste Of Asia</h2><hr>
                    <h3>{{$test->food_name}}</h3>
                </div>
               <p class="text-dark text-justify">{{$test->food_description}} </p>
            </div>
            <div class="clearfix"></div>@endforeach
        </div>
    </div>

    <div class="special-offers-section">
        <div class="special-offers-section-head text-center wow fadeInRight animated" data-wow-delay="0.4s">
            <h4>New speacial Foods</h4>
        </div>
        <div class="special-offers-section-grids">
            <div class="m_3"><span class="middle-dotted-line"> </span> </div>
            <ul id="flexiselDemo3">

                @foreach($products as $product)

                <li>


                    <div class="offer  wow fadeInUp animated" data-wow-delay="0.8s">


                        <div class="offer-image">
                            <a href="{{route('food-detail',['id'=>$product->id , 'name'=>$product->product_name])}}"><img src="{{asset($product->main_image)}}" style="height: 100px;" class="img-responsive" alt=""/></a>
                        </div>
                        <div class="offer-text">
                            <a href="{{route('food-detail',['id'=>$product->id, 'name'=>$product->product_name])}}"><h4>{{$product->product_name}}</h4></a>
                            <p>{!! $product->product_name!!} </p>
                            <p>{!! $product->product_price !!}.TK</p>
                            <a href="{{route('food-detail',['id'=>$product->id, 'name'=>$product->product_name])}}"><input type="button" value="Details"></a>


                    </div>

                        <div class="clearfix"></div>
                    </div>
                </li>@endforeach


            </ul>
            <script type="text/javascript">
                $(window).load(function() {

                    $("#flexiselDemo3").flexisel({
                        visibleItems: 3,
                        animationSpeed: 1000,
                        autoPlay: false,
                        autoPlaySpeed: 3000,
                        pauseOnHover: true,
                        enableResponsiveBreakpoints: true,
                        responsiveBreakpoints: {
                            portrait: {
                                changePoint:480,
                                visibleItems: 1
                            },
                            landscape: {
                                changePoint:640,
                                visibleItems: 2
                            },
                            tablet: {
                                changePoint:768,
                                visibleItems: 2
                            }
                        }
                    });

                });
            </script>
            <script type="text/javascript" src="{{asset('/public/public')}}/js/jquery.flexisel.js"></script>
        </div>
    </div>
    <!-- slider -->
    <div class="slider1">
        <div class="slider-info">
            <h3 class="wow bounceInLeft animated" data-wow-delay="0.4s">What Our Clients Say</h3>
            <div class="border a"></div>
        </div>
        <!-- responsiveslides -->
        <script src="{{asset('/public/public')}}/js/responsiveslides.min.js"></script>
        <script>
            // You can also use "$(window).load(function() {"
            $(function () {
                // Slideshow 4
                $("#slider3").responsiveSlides({
                    auto: true,
                    pager: false,
                    nav: false,
                    speed: 500,
                    namespace: "callbacks",
                    before: function () {
                        $('.events').append("<li>before event fired.</li>");
                    },
                    after: function () {
                        $('.events').append("<li>after event fired.</li>");
                    }
                });
            });
        </script>
        <!-- responsiveslides -->
        <div  id="top" class="callbacks_container">
            <ul class="rslides" id="slider3">
                <li>
                    <div class="slider-text wow fadeInUp animated" data-wow-delay="0.6s">
                        <p>“Aenean iaculis, mauris sed aliquet semper, nulla nisl mattis elit,
                            a volutpat nibh leo id enim. Aenean urna est, tincidunt egestas semper vitae,
                            facilisis eu tellus.”</p>
                        <a href="#">John Smith, San Francisco, CA</a>
                    </div>
                </li>
                <li>
                    <div class="slider-text wow fadeInUp animated" data-wow-delay="0.8s">
                        <p>“Tincidunt iaculis, mauris sed aliquet semper, nulla nisl mattis elit,
                            a volutpat nibh leo id enim. urna est, tincidunt egestas semper vitae,
                            facilisis eu tellus, Aenean.”</p>
                        <a href="#">Thompson, USA, CA</a>
                    </div>
                </li>
                <li>
                    <div class="slider-text wow fadeInUp animated" data-wow-delay="0.10s">
                        <p>“Facilisis eu tellus, Aenean iaculis, mauris sed aliquet semper, nulla
                            nisl mattis elit, a volutpat nibh leo id enim. Aenean urna est, tincidunt
                            egestas semper vitae.”</p>
                        <a href="#">John Doe, Argentina, CA</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <!-- //slider -->
    <div class="main-map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3983.6074608605!2d101.6778757!3d3.1973727999999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc47a8de3f55f5%3A0x3cbc4380ae4fd9ba!2sIpoh+Rd%2C+Taman+Bamboo%2C+51200+Kuala+Lumpur%2C+Federal+Territory+of+Kuala+Lumpur%2C+Malaysia!5e0!3m2!1sen!2sin!4v1429170144199" frameborder="0" style="border:0"></iframe>
    </div>
    <!-- daily -->
    <div class="daily wow  zoomInDown animated" data-wow-delay="0.4s" id="contact-us">
        <h3 class="wow rollIn animated" data-wow-delay="0.4s">Search Your favourite  Items</h3>
        <div class="col-md-8 text-field-email">
            <form  action="{{route('search')}}" method="post" role="search">
                @csrf
                <div class="form-group">
                    <input type="text" class="text" name="search_name" placeholder="enter your favourite items name" >
                </div>


  <div class="form-group">
      <button type="submit" value="Search">Search</button>
  </div>




        </form></div>
        <div class="clearfix"></div>

    </div>
    @endsection
