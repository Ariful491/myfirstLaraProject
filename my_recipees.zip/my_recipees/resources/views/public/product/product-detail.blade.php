@extends('public.master')

@section('body')

    <div class="single">
        <div class="blog-top-in">
            <div class="col-md-4 top-blog wow bounceIn animated animated" data-wow-delay="0.4s">
                <a href="#"><img class="img-responsive" src="{{asset($productDetails->main_image)}}" alt=" " ></a>
            </div>
            <div class="col-md-8 sed-in wow fadeInRight animated" data-wow-delay="0.4s">
                <h4>{{$productDetails->product_name}}</h4>
                <p>{!! $productDetails->product_details !!}</p>
                <h5>Price:-{!! $productDetails->product_price !!}TK</h5>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="at-in wow fadeInUpBig animated animated animated" data-wow-delay="0.4s">



            <h1><u>Some images:</u></h1><hr>


        @foreach(json_decode($productDetails->filename) as $img)
            <img  src="{{asset($img)}}" width="300px" height="200">

            @endforeach

    </div>
        <div class="wow fadeInDownBig animated animated animated">
            <ul class="links">
                <li><i class="date"> </i><span class="icon_text">July 14, 2014</span></li>
                <li><a href="#"><i class="admin"> </i><span class="icon_text">Admin</span></a></li>
                <li class="last"><a href="#"><i class="permalink"> </i><span class="icon_text">Permalink</span></a></li>
            </ul>
            <ul class="links links_middle">
                <li><a href="#"><i class="title-icon"> </i><span class="icon_text">Lorem Ipsum Dolore</span></a></li>
                <li><i class="tags"> </i><span class="icon_text">No tags</span></li>
            </ul>
        </div>


    @endsection
