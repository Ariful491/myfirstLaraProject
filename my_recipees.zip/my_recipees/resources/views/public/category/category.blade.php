@extends('public.master')
@section('body')

    <div class="slider-bottom text-center">
        <div class="events-info">
            <h3 class="wow fadeInLeft animated" data-wow-delay="0.4s">Check Out Our Menu</h3>
            <div class="border"></div>
            <p class="wow fadeInUpBig animated animated" data-wow-delay="0.4s">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed
                do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation </p>
        </div>
        <div class="event-grids">
            @foreach($foodProducts as $food)
            <div class="col-md-4 event-grid wow bounceIn animated" data-wow-delay="0.4s">
                <a class="event-item" href="single.html">{{$food->food_name}}</a>
                <a href="single.html"><img src="{{asset($food->food_image)}}" alt=""/></a>
            </div>
            @endforeach


            <div class="clearfix"></div>
        </div>
    </div>
    @endsection
