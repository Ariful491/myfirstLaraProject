<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','MyrcipesController@index')->name('/');

Route::get('/category/{id}','MyrcipesController@category')->name('category');
Route::get('/details/{id}/{name}','MyrcipesController@viweDetail')->name('food-detail');
Route::post('/search','MyrcipesController@search')->name('search');










Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
/* category where */
Route::get('/add-category','CategoryController@index')->name('add-category');
Route::post('/add-category/save','CategoryController@saveCategory')->name('new-category');
Route::get('/add-category/view','CategoryController@viewCategory')->name('view-category');
Route::get('/add-category/published/{id}','CategoryController@publishedCategory')->name('published-category');
Route::get('/add-category/unpublished/{id}','CategoryController@unpublishedCategory')->name('unpublished-category');
//Route::get('/add-category/edit/{id}','CategoryController@editCategory')->name('edit-category');
Route::post('/add-category/update-category','CategoryController@updateCategory')->name('update-category');
Route::get('/add-category/delete/{id}','CategoryController@deleteCategory')->name('delete-category');



/* food type where */
Route::get('/add-food-type','FoodtypeController@index')->name('add-food-type');
Route::post('/add-food-type/save_food','FoodtypeController@save_food')->name('add-food');
Route::get('/view-food-type','FoodtypeController@viewFoodtype')->name('view-food-type');
Route::get('/view-food-type/published/{id}','FoodtypeController@publishedfoodType')->name('published-foodtype');
Route::get('/view-food-type/unpublished/{id}','FoodtypeController@unpublishedfoodType')->name('unpublished-foodtype');
Route::post('/view-food-type/update-food','FoodtypeController@updateFood')->name('update-food');
Route::get('/view-food-type/delete/{id}','FoodtypeController@deleteFood')->name('delete-food');

/* product  */

Route::get('/product','ProductController@index')->name('add-product');
Route::post('/product/add','ProductController@addProduct')->name('new-product');
Route::get('/product/view','ProductController@viewProduct')->name('view-product');
Route::post('/product/edit','ProductController@editProduct')->name('edit-product');

//Route::post('/product/edit/{id}','ProductController@editProduct')->name('edit-product');










