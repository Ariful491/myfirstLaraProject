<?php

namespace App\Http\Controllers;

use App\Foodtype;
use Image;
use Illuminate\Http\Request;

class FoodtypeController extends Controller
{
    public function index(){
        return view('admin.food-type.add-food-type');
    }


    public function save_food(Request $request){

        $this->validate($request,[
            'food_name' => 'required|min:3',
            'food_description' => 'required',
            'food_image' => 'required|image',
            'status' => 'required',

        ]);
       $foodImage = $request->file('food_image');
       $ext = '.'.$request->food_image->getClientOriginalExtension();

        $imageName = str_replace($ext,date('d-m-y-H').$ext,$request->food_image->getClientOriginalName());
        $directory ='public/food-images/';
        $imageUrl = $directory.$imageName;
        //$foodImage->move($directory,$imageName);
        Image::make($foodImage)->resize(200,200)->save($imageUrl);

        $foodtype = new Foodtype();
        $foodtype->food_name = $request->food_name;
        $foodtype->food_description = $request->food_description;
        $foodtype->food_image = $imageUrl;
        $foodtype->status = $request->status;
        $foodtype->save();
        return redirect('/add-food-type')->with('text','Food Type Added Successfully');

    }

public function viewFoodtype(){
        $foodtypes = Foodtype::all();

    return view('admin.food-view.view-food-type',[
        'foodtypes'=>$foodtypes,
    ]);
}

public function publishedfoodType($id){
        $foodtype = Foodtype::find($id);
       $foodtype->status=0;
        $foodtype->save();
    return redirect('/view-food-type');

}public function unpublishedfoodType($id){
        $foodtype = Foodtype::find($id);
       $foodtype->status=1;
        $foodtype->save();
    return redirect('/view-food-type');

}
public function updateFood(Request $request){
    $foodtype = Foodtype::find($request->id);

    $foodImage = $request->file('food_image');

    if($foodImage){
        unlink($foodtype->food_image);
        $imageName =$foodImage->getClientOriginalName();
        $directory ='public/food-images/';
        $imageUrl = $directory.$imageName;
        $foodImage->move($directory,$imageName);

        $foodtype->food_name = $request->food_name;
        $foodtype->food_description = $request->food_description;
        $foodtype->food_image = $imageUrl;

    }
    else{
        $foodtype->food_name = $request->food_name;
        $foodtype->food_description = $request->food_description;


    }
    $foodtype->save();

    return redirect('/view-food-type')->with('text','Updated successfully');

}
    public function deleteFood($id){
        $category = Foodtype::find($id);
        $category->delete();
        return redirect('/view-food-type')->with('text','Deleted successfully');
    }



}
