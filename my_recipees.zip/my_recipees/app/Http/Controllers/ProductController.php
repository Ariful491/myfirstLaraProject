<?php

namespace App\Http\Controllers;

use App\Category;
use App\Foodtype;
use App\Product;
use Image;
use DB;

use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(){
        $categories = Category::where('status',1)->get();
        $foodtypes = Foodtype::where('status',1)->get();
        return view('admin.product.add-product',[
            'categories'=>$categories,
            'foodtypes'=>$foodtypes,

        ]);


    }


    protected  function productValidate($request){
        $this->validate($request,[

            'product_name'=>'required',
            'product_details'=>'required'


        ]);

    }

    protected function productMainImage($request){

        $mainImage = $request->file('main_image');

        $imageName =$mainImage->getClientOriginalName();

        $directory ='public/main-images/';
        $imageUrl = $directory.$imageName;
        //$mainImage->move($directory,$imageName);
        Image::make($mainImage)->save($imageUrl);
        return $imageUrl;
    }



    protected function saveProductInfo($request,$imageUrl){

        if($request->hasFile('filename')){
            foreach ($request->file('filename') as $img){
                $name = $img->getClientOriginalName();
                $directory ='public/gallery_images/';
                $img->move($directory, $name);
                $data[] = $directory.$name;


            }
        }



        $product = new Product();
        $product->product_name = $request->product_name;
        $product->product_details = $request->product_details;
        $product->product_price = $request->product_price;
        $product->cupon_price = $request->cupon_price;
        $product->category_id = $request->category_id;
        $product->food_id = $request->food_id;

        $product->product_size = $request->product_size;
        $product->main_image = $imageUrl;
        $product->filename =json_encode($data);
        $product->save();

    }







    public function addProduct(Request $request){
                         $this->productValidate($request);
                         $imageUrl = $this->productMainImage($request);




        $this->saveProductInfo($request,$imageUrl);

        return redirect('/product')->with('text','Product Added successfully');

    }







    public function viewProduct(){

        $products = DB::table('products')
                                    ->join('categories','products.category_id','=','categories.id')
                                    ->join('foodtypes','products.food_id','=','foodtypes.id')
                                    ->get();





       // return $products ;

        return view('admin.view-product.view',[
            'products' => $products,
        ]);
    }


public function editProduct(Request $request){
        $product = Product::find($request->id);

        $product->product_name = $request->product_name;
        $product->save();

        return redirect('/product/view');

}









}
