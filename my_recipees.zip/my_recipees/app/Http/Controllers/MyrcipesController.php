<?php

namespace App\Http\Controllers;

use App\Category;
use App\Foodtype;
use App\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

class MyrcipesController extends Controller
{
    public function index(){


        $products = Product::orderby('id','DESC')->get();

        $testOfAsia = Foodtype::orderBy('id','DESC')->take(1)->get();

        return view('public.home.home',[
        'products'=>$products,
            'testOfAsian'=> $testOfAsia,

            ]);
    }



    public function category(){
        $foodProducts = Foodtype::orderby('id','DESC')->skip(3)->take(6)->where('status',1)->get();

        return view('public.category.category',[
            'foodProducts'=>$foodProducts,
        ]);
    }




    public function viweDetail($id){

        $productDetails = Product::find($id);


        return view('public.product.product-detail',[
            'productDetails'=>$productDetails
        ]);
    }

    public function search(){
      $SearchName = Input::get('search_name');
        if($SearchName != ''){

            $product = Product::where('product_name','like','%'.$SearchName.'%')

                ->orwhere('product_details','like','%'.$SearchName.'%')
                ->get();

            if(count($product)>0){
                return redirect('/')->with($product)->with($SearchName);
            }

        }
        return redirect('/')->with('text','Nothing Found');


    }
}
