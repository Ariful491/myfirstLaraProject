<?php

namespace App\Http\Controllers;
use App\Category;


use Illuminate\Http\Request;

class CategoryController extends Controller
{
public function index(){
    return view('admin.category.add-category');
}
public function saveCategory(Request $request){
    $this->validate($request,[

        'cat_nam'=> 'required',
        'cat_desc'=> 'required',
        'cat_image'=> 'required|image',
         'status'=> 'required'
    ]);

    $categoryImage = $request->file('cat_image');
    $imageName =$categoryImage->getClientOriginalName();
    $directory ='public/category-images/';
    $imageUrl = $directory.$imageName;
    $categoryImage->move($directory,$imageName);

   $category = new Category();
   $category->cat_nam = $request->cat_nam;
   $category->cat_desc = $request->cat_desc;
   $category->cat_image = $imageUrl;
   $category->status = $request->status;
   $category->save();


   return  redirect('/add-category')->with('text','Category added successfully');

}


public function viewCategory(){


    $categories = Category::all();
    return view('admin.viewCategory.view' ,['categories'=>$categories]);
}


public function publishedCategory($id){
    $category = Category::find($id);
    $category->status = 0;
    $category-> save();
    return redirect('/add-category/view');


}
public function unpublishedCategory($id){

    $category = Category::find($id);
    $category->status = 1;
    $category-> save();
    return redirect('/add-category/view');


}
//public function editCategory($id){
//    $category = Category::find($id);
////    return $category;
//    return view('admin.viewCategory.view' ,['category'=>$category]);
//
//}

public function updateCategory(Request $request){
    $category = Category::find($request->id);
    $categoryImage = $request->file('cat_image');

    if($categoryImage){
        unlink($category->cat_image);
        $imageName =$categoryImage->getClientOriginalName();
        $directory ='public/category-images/';
        $imageUrl = $directory.$imageName;
        $categoryImage->move($directory,$imageName);

        $category->cat_nam = $request->cat_nam;
        $category->cat_desc = $request->cat_desc;
        $category->cat_image = $imageUrl;

    }
    else{
        $category->cat_nam = $request->cat_nam;
        $category->cat_desc = $request->cat_desc;


    }
    $category->save();

    return redirect('/add-category/view')->with('text','updated succesfully');

}
public function deleteCategory($id){
    $category = Category::find($id);
    $category->delete();
    return redirect('/add-category/view')->with('text','deleted succesfully');
}

}
