<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Foodtype;
use App\Model;
use Faker\Generator as Faker;

$factory->define(Foodtype::class, function (Faker $faker) {
    return [
        'food_name'=>$faker->word,
        'food_description'=>$faker->sentence,
        'food_image'=>$faker->imageUrl,
        'status'=>rand(0,1),
    ];
});
