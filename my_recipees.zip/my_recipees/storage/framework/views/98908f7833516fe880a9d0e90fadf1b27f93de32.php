<div class="footer">
    <div class="container">
        <p class="wow bounceInLeft animated" data-wow-delay="0.4s">&copy; 2019 My Recipes . All rights  Reserved | Design by &nbsp;<a href="http://w3layouts.com" target="target_blank">W3layouts</a></p>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/public/includes/footer.blade.php ENDPATH**/ ?>