<?php $__env->startSection('body'); ?>

    <div class="container-fluid">

        <?php if(Session::get('text')): ?>
            <div class="col-md-4 ml-auto">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <h1><?php echo e(Session::get('text')); ?></h1>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>
            </div>

        <?php endif; ?>


        <h1>Food Types</h1>
            <?php echo e(Form::open(['route'=>'add-food','enctype'=>'multipart/form-data'])); ?>


            <div class="form-group">
            <?php echo e(Form::label('Food Name')); ?><sup class="text-danger">*</sup>:
            <?php echo e(Form::text('food_name','',['class'=>'form-control bg-white text-dark',])); ?>

                <span style="color: red"><?php echo e($errors->has('food_name') ? $errors->first('food_name'):''); ?></span>
            </div>

            <div class="form-group">
            <?php echo e(Form::label('Food Description')); ?><sup class="text-danger">*</sup>:
            <?php echo e(Form::textarea('food_description','',['class'=>'form-control bg-white text-dark ','rows'=>'5'])); ?>

                <span cstyle="color: red"><?php echo e($errors->has('food_description') ? $errors->first('food_description'):''); ?></span>

            </div>

          <div class="form-group">
            <?php echo e(Form::label('Food image')); ?><sup class="text-danger">*</sup>:
            <?php echo e(Form::file('food_image',['class'=>'form-control-file'])); ?>

              <span style="color: red"><?php echo e($errors->has('food_image') ? $errors->first('food_image'):''); ?></span>

          </div>

            <div class="form-group">
            <?php echo e(Form::label('Publication Status')); ?><sup class="text-danger">*</sup>:
                <div class="radio">
                    <?php echo e(Form::radio('status','1')); ?>Published
                    <?php echo e(Form::radio('status','0')); ?>Unpublished
                </div>
                <span style="color: red"><?php echo e($errors->has('status') ? $errors->first('status'):''); ?></span>

            </div>
             <hr>

            <div class="form-group">
                <?php echo e(Form::submit('Add Food Type',['class'=>'btn btn-danger'])); ?>

            </div>
             <?php echo e(Form::close()); ?>


    </div>
    <!-- /.container-fluid -->

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/admin/food-type/add-food-type.blade.php ENDPATH**/ ?>