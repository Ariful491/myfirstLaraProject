<?php $__env->startSection('body'); ?>


    <!-- Begin Page Content -->
    <div class="container-fluid">
        <?php if(Session::get('text')): ?>
            <div class="col-md-4 ml-auto ">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <h1><?php echo e(Session::get('text')); ?></h1>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>
            </div>

        <?php endif; ?>
        <h1>View Product</h1>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">Serial</th>
                <th scope="col">Product Name</th>
                <th scope="col">Price</th>
                <th scope="col"> Image</th>
                <th scope="col"> Category</th>
                <th scope="col"> Food Type</th>

                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php ($i=1); ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>


                    <td scope="row"><?php echo e($i++); ?> </td>
                    <td><?php echo e($product->product_name); ?></td>
                    <td><?php echo e($product->product_price); ?></td>
                    <td><img  src="<?php echo e(asset($product->main_image)); ?>" width="100"  > </td>
                    <td><?php echo e($product->cat_nam); ?></td>
                    <td><?php echo e($product->food_name); ?></td>


                    <td><!-- Button trigger modal -->


                        <button  type="button" class="btn btn-info" data-toggle="modal" data-target="#view<?php echo e($product->id); ?>">
                            <i class="fas fa-search-plus"></i>
                        </button>

                        <button  type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit<?php echo e($product->id); ?>">
                            <i class="fas fa-edit"></i>
                        </button>

                        <a href="<?php echo e(route('delete-category',['id'=>$product->id])); ?>" type="button" class="btn btn-danger" >
                            <i class="fas fa-trash"></i>
                        </a>



                    </td>
                </tr>



                <?php echo $__env->make('admin.product.includes.view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <?php echo $__env->make('admin.product.includes.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>








































            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <!-- /.container-fluid -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/admin/view-product/view.blade.php ENDPATH**/ ?>