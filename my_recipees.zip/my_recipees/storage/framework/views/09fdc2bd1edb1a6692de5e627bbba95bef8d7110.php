<?php $__env->startSection('body'); ?>


    <!-- Begin Page Content -->
    <div class="container-fluid">
        <?php if(Session::get('text')): ?>
            <div class="col-md-4 ml-auto">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <h1><?php echo e(Session::get('text')); ?></h1>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>
            </div>

        <?php endif; ?>


        <h1>Add Product</h1>

        <form action="<?php echo e(route('new-product')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="categoryname">Product Name</label>
                <input type="text" name="product_name" class="form-control" id="categoryname">
            </div>
            <div class="form-group">
                <label for="product-details">Product Details</label>
                <textarea rows="5"class="form-control" name="product_details" id="editor"></textarea>
            </div>
            <div class="form-group">
                <label for="categoryname">Product Price</label>
                <input type="text" class="form-control" name="product_price" id="categoryname">
            </div>
            <div class="form-group">
                <label for="categoryname">Product Cupon Price</label>
                <input type="text" class="form-control" name="cupon_price" id="categoryname">
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect1">select category </label>
                <select class="form-control" id="exampleFormControlSelect1" name="category_id">
                    <option>---Select Category---</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->cat_nam); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>

            <div class="form-group">
                <label for="exampleFormControlSelect1">select Food Type </label>
                <select class="form-control" id="exampleFormControlSelect1" name="food_id">
                    <option>---Select Food Type---</option>
                    <?php $__currentLoopData = $foodtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($foodtype->id); ?>"><?php echo e($foodtype->food_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>










            <div class="form-group">
                <label for="exampleFormControlSelect1">select Quantity</label>
                <select class="form-control" id="exampleFormControlSelect1" name="product_size">
                    <option >--Select Food Quantity </option>
                    <option value="m" >m</option>
                    <option value="l">l</option>
                    <option value="x">x</option>
                    <option value="xl">xl</option>
                    <option value="xxl">xxl</option>
                </select>
            </div>
            <div class="form-group">
                <label for="exampleFormControlFile1">Image</label>

                <input type="file" class="form-control-file" id="exampleFormControlFile1" name="main_image">
            </div>
            <div class="form-group">
                <label for="exampleFormControlFile1">Image Gallery</label>

                <input type="file" class="form-control-file" id="exampleFormControlFile1" multiple name="filename[]">
            </div>
            <input type="submit" class="btn btn-primary">
        </form>

    </div>
    <!-- /.container-fluid -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/admin/product/add-product.blade.php ENDPATH**/ ?>