<div class="banner wow fadeInUp animated" data-wow-delay="0.4s">
    <!---->
    <div class="slider">
        <div class="callbacks_container">
            <ul class="rslides" id="slider">
                <li>
                    <img src="<?php echo e(asset('/public/public')); ?>/images/1.jpg" alt=""/>
                    <div class="caption1">
                        <div class="top-menu wow rollIn animated" data-wow-delay="0.4s">
                            <span class="menu lft"> </span>
                            <ul>
                                <li><a class="" href="<?php echo e(route('/')); ?>">Home</a></li>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a class="" href="<?php echo e(route('category',['id'=>$category->id])); ?>"><?php echo e($category->cat_nam); ?></a></li>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="clearfix"></div>
                            </ul>
                        </div>
                    </div>
                </li>
                <li>
                    <img src="<?php echo e(asset('/public/public')); ?>/images/2.jpg" alt=""/>
                    <div class="caption1">
                        <div class="top-menu">
                            <span class="menu lft"> </span>
                            <ul>
                                <li><a class="" href="<?php echo e(route('/')); ?>">Home</a></li>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a class="" href="<?php echo e(route('category',['id'=>$category->id])); ?>"><?php echo e($category->cat_nam); ?> </a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="clearfix"></div>
                            </ul>
                        </div>
                    </div>
                </li>
                <li>
                    <img src="<?php echo e(asset('/public/public')); ?>/images/3.jpg" alt=""/>
                    <div class="caption1">
                        <div class="top-menu">
                            <span class="menu lft"> </span>
                            <ul>
                                <li><a class="" href="<?php echo e(route('/')); ?>">Home</a></li>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a class="" href="<?php echo e(route('category',['id'=>$category->id])); ?>"><?php echo e($category->cat_nam); ?></a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="clearfix"></div>
                            </ul>
                        </div>
                        <!-- script-for-menu -->
                        <script>
                            $("span.menu").click(function(){
                                $(".top-menu ul").slideToggle("slow" , function(){
                                });
                            });
                        </script>
                        <!-- script-for-menu -->

                    </div>
                </li>
            </ul>
        </div>
    </div>
    <!----->
</div>
<?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/public/includes/top-nav.blade.php ENDPATH**/ ?>