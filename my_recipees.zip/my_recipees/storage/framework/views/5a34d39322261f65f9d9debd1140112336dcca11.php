<?php $__env->startSection('body'); ?>

    <div class="slider-bottom text-center">
        <div class="events-info">
            <h3 class="wow fadeInLeft animated" data-wow-delay="0.4s">Check Out Our Menu</h3>
            <div class="border"></div>
            <p class="wow fadeInUpBig animated animated" data-wow-delay="0.4s">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed
                do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation </p>
        </div>
        <div class="event-grids">
            <?php $__currentLoopData = $foodProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 event-grid wow bounceIn animated" data-wow-delay="0.4s">
                <a class="event-item" href="single.html"><?php echo e($food->food_name); ?></a>
                <a href="single.html"><img src="<?php echo e(asset($food->food_image)); ?>" alt=""/></a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="clearfix"></div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('public.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/public/category/category.blade.php ENDPATH**/ ?>