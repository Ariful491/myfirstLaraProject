<div class="event-grids">
    <div class="col-md-6 event-grid wow bounceIn animated" data-wow-delay="0.4s">
        <a class="event-item" href="single.html">GRILL FEST</a>
        <a href="single.html"><img src="<?php echo e(asset('/public/public')); ?>/images/9.jpg" alt=""/></a>
    </div>
    <div class="col-md-6 event-grid wow bounceIn animated" data-wow-delay="0.4s">
        <a class="event-item" href="single.html">COFFEE WEEK</a>
        <a href="single.html"><img src="<?php echo e(asset('/public/public')); ?>/images/10.jpg" alt=""/></a>
    </div>
    <div class="clearfix"></div>
</div>
<?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/public/includes/event-grids.blade.php ENDPATH**/ ?>