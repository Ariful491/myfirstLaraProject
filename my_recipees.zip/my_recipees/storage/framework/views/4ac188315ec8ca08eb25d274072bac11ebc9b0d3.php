<?php $__env->startSection('body'); ?>
    <div class="container-fluid">
        <?php if(Session::get('text')): ?>
            <div class="col-md-4 ml-auto ">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <h1><?php echo e(Session::get('text')); ?></h1>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>
            </div>

        <?php endif; ?>
        <h1>View Food Types</h1>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">Serial</th>
                <th scope="col">Food Name</th>
                <th scope="col">Food Description</th>
                <th scope="col">Food Image</th>
                <th scope="col">Publication Status</th>
                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php ($i=1); ?>
            <?php $__currentLoopData = $foodtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>


                    <td scope="row"><?php echo e($i++); ?> </td>
                    <td><?php echo e($foodtype->food_name); ?></td>
                    <td><?php echo e($foodtype->food_description); ?></td>
                    <td><img  src="<?php echo e(asset($foodtype->food_image)); ?>" width="100"  > </td>
                    <td><?php echo e($foodtype->status==1?'publish':'unpublished'); ?></td>

                    <td><!-- Button trigger modal -->
                        <?php if($foodtype->status==1): ?>
                            <a href="<?php echo e(route('published-foodtype',['id'=>$foodtype->id])); ?>" type="button" class="btn btn-info" >
                                <i class=" fas fa-arrow-up"></i>
                            </a>
                        <?php else: ?>

                            <a href="<?php echo e(route('unpublished-foodtype',['id'=>$foodtype->id])); ?>" type="button" class="btn btn-warning" >
                                <i class="fas fa-arrow-down"></i>
                            </a>
                        <?php endif; ?>

                        <button  type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal<?php echo e($foodtype->id); ?>">
                            <i class="fas fa-edit"></i>
                        </button>

                        <a href="<?php echo e(route('delete-food',['id'=>$foodtype->id])); ?>" type="button" class="btn btn-danger" >
                            <i class="fas fa-trash"></i>
                        </a>



                    </td>
                </tr>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal<?php echo e($foodtype->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Update Food Types</h5>
                                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('update-food')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label >Food Name</label>
                                        <input type="text"  name="food_name" class="form-control" value="<?php echo e($foodtype->food_name); ?>">
                                        <input type="hidden"  name="id" class="form-control" value="<?php echo e($foodtype->id); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label >Food Description</label>
                                        <textarea rows="4" name="food_description" class="form-control" ><?php echo e($foodtype->food_description); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleFormControlFile1">Image</label>
                                        <h5>Previus Image</h5>
                                        <img src="<?php echo e(asset($foodtype->food_image)); ?>" alt="" width="200px" height="200px" >
                                        <br><br>
                                        <input type="file" class="form-control-file"  name="food_image" id="exampleFormControlFile1">
                                    </div>
                                    <input type="submit" class="btn btn-success" name="btn" value="Update Food">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <!-- /.contai

    <?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/admin/food-view/view-food-type.blade.php ENDPATH**/ ?>