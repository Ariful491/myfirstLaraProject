

                <!-- Modal -->
                <div class="modal fade" id="edit<?php echo e($product->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">View Product Info</h5>
                                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('edit-product')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label >Product Name:</label>
                                        <input type="text"  name="product_name" class="form-control" value="<?php echo e($product->product_name); ?>">
                                        <input type="hidden"  name="id" class="form-control" value="<?php echo e($product->id); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label >Product Details:</label>
                                        <input type="text"  name="product_details" class="form-control" value="<?php echo $product->product_details; ?>">

                                    </div>
                                    <div class="form-group">
                                        <label >Product Price:</label>
                                        <input type="text"  name="product_price" class="form-control" value="<?php echo e($product->product_price); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label >Cupon Price:</label>
                                        <input type="text"  name="cupon_price" class="form-control" value="<?php echo e($product->cupon_price); ?>">
                                    </div>



                                    <div class="form-group">
                                        <label for="exampleFormControlFile1">Image</label>
                                        <h5>Product Image:</h5>
                                        <img src="<?php echo e(asset($product->main_image)); ?>" alt="" width="200px" height="200px" >
                                        <br>
                                        <input type="file" class="form-control-file"  name="main_image" id="exampleFormControlFile1">
                                    </div>
                                     <div class="form-group">
                                        <label for="exampleFormControlFile1">Image</label>
                                        <h5>Product Gallery:</h5>

                                         <?php $__currentLoopData = json_decode($product->filename); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <img  src="<?php echo e(asset($img)); ?>" width="300px" height="200">
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <br> <br>
                                        <input type="file" class="form-control-file"  name="filename[]" id="exampleFormControlFile1" multiple>
                                    </div>


                                    <input type="submit" class="btn btn-success" name="btn" value="Update Products">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
<?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/admin/product/includes/edit.blade.php ENDPATH**/ ?>