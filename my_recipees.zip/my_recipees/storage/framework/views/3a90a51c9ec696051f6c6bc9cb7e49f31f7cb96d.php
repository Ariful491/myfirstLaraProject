<?php $__env->startSection('body'); ?>
    <div class="container-fluid  ">
        <h1>Dashboard</h1>
        <p>Welcome to my admin panel</p>




    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/admin/home/home.blade.php ENDPATH**/ ?>