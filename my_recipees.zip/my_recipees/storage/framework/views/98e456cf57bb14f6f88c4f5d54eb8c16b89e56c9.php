<?php $__env->startSection('body'); ?>
    <!-- Begin Page Content -->


    <div class="container-fluid">

        <?php if(Session::get('text')): ?>
            <div class="col-md-4 ml-auto">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <h1><?php echo e(Session::get('text')); ?></h1>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>
            </div>

          <?php endif; ?>







        <h1>category</h1>
        <form action="<?php echo e(route('new-category')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="categoryname">Category Name<sup class="text-danger">*</sup>:</label>
                <input type="text" class="form-control" name="cat_nam" id="categoryname">
                <span class="text-danger"><?php echo e($errors->has('cat_nam') ? $errors->first('cat_nam'):''); ?></span>

            </div>

            <div class="form-group">
                <label for="categorydesc">Category Description<sup class="text-danger">*</sup>:</label>
                <textarea rows="5" class="form-control" name="cat_desc" id="categorydesc"></textarea>
                <span class="text-danger"><?php echo e($errors->has('cat_desc') ? $errors->first('cat_desc'):''); ?></span>
            </div>


            <div class="form-group">
                <label for="exampleFormControlFile1">Image<sup class="text-danger">*</sup>:</label>

                <input type="file" class="form-control-file" name="cat_image" id="exampleFormControlFile1">
                <span class="text-danger"><?php echo e($errors->has('cat_image') ? $errors->first('cat_image'):''); ?></span>
            </div>


            <div class="form-group">
                <label for="status">Publication Status<sup class="text-danger">*</sup>:</label>

                <div class="radio">
                    <input type="radio" name="status" value="1">Published
                    <input type="radio" name="status" value="0">Unpublished
                </div>
                <span class="text-danger"><?php echo e($errors->has('status') ? $errors->first('status'):''); ?></span>
            </div>



            <hr>
            <input type="submit" class="btn btn-danger" value="Add Category">
        </form>

    </div>
    <!-- /.container-fluid -->

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/admin/category/add-category.blade.php ENDPATH**/ ?>