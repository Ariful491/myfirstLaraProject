<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php /**PATH F:\xampp\htdocs\my_recipees\resources\views/admin/includes/scroll.blade.php ENDPATH**/ ?>